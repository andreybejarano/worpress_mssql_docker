# Metrogas Firmas

> Generador de firmas, con ingreso mediante validación .HTACCESS

## Puesta en marcha:

- Ingresar url del proyecto en la linea 1 del /index.php.
- Ingresar la ruta absolute en el app/.htaccess
- Ingresar la ruta absolute en el .htaccess

(FYI la ruta absoluta se puede obtener con la función -> 'echo getcwd();' en PHP)

## Datos para probar

Usuario: MGAS
Contraseña: firma@mail943
